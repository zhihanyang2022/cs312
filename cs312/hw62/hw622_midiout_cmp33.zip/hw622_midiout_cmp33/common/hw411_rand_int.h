/******************************************************
hw411_rand_int.h
Copyright (c) Carleton College CS312 free open source
Assignment: hw411
Zhihan Yang yangz2@carleton.edu
DATE: 2020-02-02
TIME: 20-25-12
******************************************************/

// hw411_rand_int.h
#ifndef HW411_RAND_INT_H_
#define HW411_RAND_INT_H_

extern int get_rand_int(int lo, int hi);

#endif // HW411_RAND_INT_H_